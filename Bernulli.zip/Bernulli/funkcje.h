#ifndef FUNCJE_INCLUDED
#define FUNCJE_INCLUDED

#include <math.h>

double power (double  podstawa, int wykladnik)
{
    return pow(podstawa,wykladnik);
}

int silnia(int a)
{
    int silnia=1;
    int i;
    for (i = 1; i<=a ; ++i)
    {
       silnia*=i;
    }
    return silnia;
}

int symbolNewtona( int n, int k)
{
   return 0;
}

#endif // FUNCJE_INCLUDED
