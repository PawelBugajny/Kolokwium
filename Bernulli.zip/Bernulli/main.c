#include <stdio.h>
#include <stdlib.h>
#include "funkcje.h"

/*
Funkcje dostęne:
- silnia(int) - zwraca wartość silni od podanej watości typu całkowitego
-power(double, int) - zwraca wartość potęgi double^int
*/

int main()
{
    printf("Hello world!\n %d", silnia(10) );
    printf("\n cos %f", power(0.5, 5));

    return 0;
}
